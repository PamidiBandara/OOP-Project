package com.smartbookshop.smart_bookshop.repository;

import com.smartbookshop.smart_bookshop.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {

}
