package com.smartbookshop.smart_bookshop.controller;

import com.smartbookshop.smart_bookshop.entity.Product;
import com.smartbookshop.smart_bookshop.service.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService){
        this.productService = productService;
    }

    @GetMapping("/products")
    public String viewProducts(Model model){

        model.addAttribute("products",
                productService.getAllProducts());

        return "products";
    }
    @GetMapping("/add-product")
    public String addProductPage(Model model) {

        model.addAttribute("product", new Product());

        return "add-product";

    }
    @PostMapping("/save-product")
    public String saveProduct(@ModelAttribute Product product) {

        productService.saveProduct(product);

        return "redirect:/products";
    }
    @GetMapping("/delete-product/{id}")
    public String deleteProduct(@PathVariable Long id){

        productService.deleteProduct(id);

        return "redirect:/products";
    }

}
