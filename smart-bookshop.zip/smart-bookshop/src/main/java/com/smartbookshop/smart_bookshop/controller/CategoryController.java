package com.smartbookshop.smart_bookshop.controller;

import com.smartbookshop.smart_bookshop.service.CategoryService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CategoryController {

    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @GetMapping("/categories")
    public String viewCategories(Model model) {

        model.addAttribute("categories", categoryService.getAllCategories());

        return "categories";
    }
}