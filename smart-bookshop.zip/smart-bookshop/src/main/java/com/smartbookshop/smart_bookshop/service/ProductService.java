package com.smartbookshop.smart_bookshop.service;

import com.smartbookshop.smart_bookshop.entity.Product;
import com.smartbookshop.smart_bookshop.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    // Save Product
    public Product saveProduct(Product product){
        return productRepository.save(product);
    }

    // Get All Products
    public List<Product> getAllProducts(){
        return productRepository.findAll();
    }

    // Get Product By Id
    public Product getProductById(Long id){
        return productRepository.findById(id).orElse(null);
    }

    // Delete Product
    public void deleteProduct(Long id){
        productRepository.deleteById(id);
    }
}